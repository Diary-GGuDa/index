<?php 
    if(!isset($_SESSION['myMemberID'])){
        //로그인 페이지 이동
        // msg("로그인을 먼저 해주세요 :3");
        echo "<script>alert('로그인을 먼저 해주세요 :3')</script>";
        echo "<script>location.href='../main/main.php'</script>";
    }
?>
<!-- <script>
    alert("로그인을 먼저 해주세요 :3")
    location.href="../main/main.php";
</script> -->
